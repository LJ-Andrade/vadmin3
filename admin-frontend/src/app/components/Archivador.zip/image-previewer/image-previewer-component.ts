import { CommonModule, DOCUMENT } from '@angular/common';
import { Component, EventEmitter, Input, Output, Renderer2, inject } from '@angular/core';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { ImageCropperComponent, ImageCroppedEvent } from 'ngx-image-cropper';

@Component({
	selector: 'app-image-previewer',
	standalone: true,
	imports: [CommonModule, DialogModule, ButtonModule, ImageCropperComponent],
	templateUrl: './image-previewer.component.html',
	styleUrl: './image-previewer.component.sass'
})

export class ImagePreviewerComponent {
	renderer = inject(Renderer2);
	document = inject(DOCUMENT);

	actionIsLoading = false;
	confirmingDelete = false;

	@Input() image?: string;
	@Input() allowDelete = true;
	@Output() deleteImageRequested = new EventEmitter<void>();
	@Output() imageCropped = new EventEmitter<string>();

	fullImage = false;

	// CROP
	cropperVisible = false;
	croppedImage = '';
	imageChangedEvent: any = null;

	showExistingImage(image: string) {
		this.image = image;
	}

	showFullImage() {
		const fullImage = this.document.querySelector('.full-image');
		this.renderer.appendChild(this.document.body, fullImage);
		this.fullImage = true;
	}

	hideFullImage() {
		this.fullImage = false;
	}

	askImageDeletion() {
		this.confirmingDelete = true;
	}

	requestImageDeletion() {
		this.actionIsLoading = true;
		this.confirmingDelete = false;
		this.deleteImageRequested.emit();
	}

	cancelImageDeletion() {
		this.confirmingDelete = false;
		this.actionFinished();
	}

	imageDeletedSuccessfully() {
		this.actionFinished();
		this.image = undefined;
	}

	actionFinished() {
		this.actionIsLoading = false;
	}

	// CROP
	openCropper() {
		if (!this.image) return;
		this.croppedImage = '';
		setTimeout(() => {
			// Forzar re-render para que Angular vuelva a evaluar el binding
			this.image = this.image + '';
			this.cropperVisible = true;
		}, 0);
	}

	onImageCropped(event: ImageCroppedEvent) {
		console.log('Cropped image event:', event);
		this.croppedImage = event.base64 ?? '';

	}

	applyCroppedImage() {
		if (this.croppedImage) {
			this.image = this.croppedImage;
			this.imageCropped.emit(this.croppedImage);  // no se necesita index
		}
		this.cropperVisible = false;
		this.croppedImage = '';
	}
	
	imageLoaded() {
		// Podés agregar lógica si querés
	}

	loadImageFailed() {
		console.warn('Falló la carga de imagen en el cropper');
	}
}
