export const environment = {
    apiUrl: 'https://studiovimana.com.ar/api/',
    production: true,
    tokenKeyName: 'vadmin3-token',
    byPassLogin: false,
};
