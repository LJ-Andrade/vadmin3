export const environment = {
    apiUrl: 'http://vadmin3.test/api/',
    production: false,
	tokenKeyName: 'vadmin3-token',
    byPassLogin: false,
};