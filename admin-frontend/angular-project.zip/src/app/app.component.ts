import { Component, inject } from '@angular/core'
import { RouterOutlet } from '@angular/router'
import { ToastModule } from 'primeng/toast'
import { AuthService } from '@services/auth/auth.service'
import { SkinService } from './services/skin.service'

@Component({
    selector: 'app-root',
    standalone: true, 
    imports: [ RouterOutlet, ToastModule ],
    templateUrl: './app.component.html',
    styleUrl: './app.component.sass'
})

export class AppComponent {
    title = 'frontend'

    constructor(private authService: AuthService) {}
    skinService: SkinService = inject(SkinService)

    async ngOnInit() {
        this.authService.retrieveLoggedUser()
        this.skinService.initializeSkin()
	}
}