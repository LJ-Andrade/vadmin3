import { Injectable, inject, signal, computed } from '@angular/core';
import { DataService } from './data.service';
import { firstValueFrom } from 'rxjs';

interface SkinState {
	primaryColor: string;
	secondaryColor: string;
	logo?: string;
}

@Injectable({
	providedIn: 'root'
})

export class SkinService {
	private dataService: DataService = inject(DataService);

	private skinState = signal<SkinState>({
		primaryColor: '',
		secondaryColor: '',
		logo: ''
	});

	public primaryColor = computed(() => this.skinState().primaryColor);
	public secondaryColor = computed(() => this.skinState().secondaryColor);

	initializeSkin() {
		// console.log('Initializing skin');

		const domain = window.location.hostname;

		if (domain) {
			this.setOrRecoverClientSkin(domain);
		} else {
			console.error('No domain provided in URL, using default skin');
			this.applySkinStyles('#007bff', '#6c757d');
		}
	}

	private setOrRecoverClientSkin(domain: string) {
		const storedSkinRaw = localStorage.getItem(domain);

		if (storedSkinRaw != null) {
			const storedSkin = JSON.parse(storedSkinRaw);

			this.skinState.update((state) => ({
				...state,
				primaryColor: storedSkin.primaryColor,
				secondaryColor: storedSkin.secondaryColor
			}));

			this.applySkinStyles();
			// console.log('Stored skin applied:', storedSkin);
		} else {
			// console.log('No stored skin, recovering from API');
			this.recoverClientSkin(domain);
		}
	}

	private async recoverClientSkin(domain: string) {
		try {
			const response: any = await firstValueFrom(
				this.dataService.httpFetch(`clients/skin?domain=${domain}`)
			);

			const primaryColor = response.data.primary_color;
			const secondaryColor = response.data.secondary_color;

			localStorage.setItem(domain, JSON.stringify({
				primaryColor,
				secondaryColor
			}));

			this.skinState.update((state) => ({
				...state,
				primaryColor,
				secondaryColor
			}));

			this.applySkinStyles();
			// console.log('Client skin styles applied:', { primaryColor, secondaryColor });
		} catch (error) {
			console.error('Error loading skin:', error);
			this.applySkinStyles('#007bff', '#6c757d');
		}
	}

	private applySkinStyles(primaryColor: string = '', secondaryColor: string = '') {
		this.skinState.update((state) => ({
			...state,
			primaryColor: primaryColor || state.primaryColor,
			secondaryColor: secondaryColor || state.secondaryColor
		}));

		const appliedPrimary = this.skinState().primaryColor;
		const appliedSecondary = this.skinState().secondaryColor;

		// console.log('Applying skin styles:', { appliedPrimary, appliedSecondary });

		let styleElement = document.getElementById('client-skin-styles');

		if (!styleElement) {
			styleElement = document.createElement('style');
			styleElement.id = 'client-skin-styles';
			document.head.appendChild(styleElement);
		}

		styleElement.textContent = `
			.client-primary-color { color: ${appliedPrimary} !important; }
			.client-primary-bg { background-color: ${appliedPrimary} !important; }
			.client-secondary-color { color: ${appliedSecondary} !important; }
			.client-secondary-bg { background-color: ${appliedSecondary} !important; }
		`;
	}
}
