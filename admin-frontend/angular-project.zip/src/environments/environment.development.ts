export const environment = {
    // apiUrl: 'http://api.boilerplate.com/',
    apiUrl: 'https://api.fsr.innovastudio.com.ar/api/',
    production: false,
	tokenKeyName: 'fsr-token',
    byPassLogin: false,
};