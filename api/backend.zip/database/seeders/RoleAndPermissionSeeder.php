<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RoleAndPermissionSeeder extends Seeder
{
    public function run(): void
    {
        // Lista de permisos de tu app
        $permissions = [
            'users.list',
            'users.store',
            'users.show',
            'users.update',
            'users.delete',
            // Agrega más permisos si los necesitás
        ];

        // Crear permisos
        foreach ($permissions as $permission) {
            Permission::firstOrCreate(['name' => $permission]);
        }

        // Crear el rol admin (si no existe)
        $adminRole = Role::firstOrCreate(['name' => 'admin']);

        // Asignar todos los permisos al rol admin
        $adminRole->syncPermissions(Permission::all());

        $this->command->info('Permisos y rol admin creados correctamente.');
    }
}
