<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // Crear usuario admin
        $admin = User::firstOrCreate(
            [
                'email' => 'admin@admin.com',
                'last_name' => 'Admin',
                'first_name' => 'Admin',
                'username' => 'admin',
                'password' => bcrypt('12121212'), // Cambiá esto después!
            ]
        );

        // Asignar el rol 'admin'
        $admin->assignRole('admin');
    }
}
