<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Services\AIQueryService;
use App\Services\SQLValidator;
use App\Services\SQLCleaner;

class AIQueryController extends Controller
{
    // Log::info('Prompt recibido: ' . $prompt);
    // Log::info('SQL generado: ' . $sql);
    public function handle(Request $request)
    {
        $prompt = $request->input('prompt');
    
        if (!$prompt) {
            return response()->json(['error' => 'Prompt vacío'], 400);
        }
    
        $sql = app(AIQueryService::class)->generateSQL($prompt);
    
        if (!$sql) {
            return response()->json(['error' => 'No se pudo generar SQL'], 500);
        }
    
        Log::info('SQL generado por Groq: ' . $sql);
    
        // Limpiar SQL
        $sql = SQLCleaner::clean($sql);
    
        // Revisar subqueries
        if (SQLCleaner::hasSubquery($sql)) {
            Log::warning('Subquery detectada: ' . $sql);
            return response()->json(['error' => 'Subqueries no permitidas por seguridad'], 400);
        }
    
        // Validar tablas y tipo de consulta
        if (!app(SQLValidator::class)->isValid($sql)) {
            return response()->json(['error' => 'SQL inválido o no permitido'], 400);
        }
    
        // Detectar funciones agregadas (COUNT, SUM, AVG, MIN, MAX)
        $isAggregateQuery = preg_match('/\\b(count|sum|avg|min|max)\\s*\\(/i', $sql);
    
        // Agregar LIMIT si corresponde
        if (!$isAggregateQuery && !preg_match('/limit\\s+\\d+/i', strtolower($sql))) {
            $sql .= ' LIMIT 100';
        }
    
        try {
            $results = DB::select($sql);
        } catch (\Exception $e) {
            Log::error('Error ejecutando SQL IA: ' . $e->getMessage());
            return response()->json([
                'error' => 'Error al ejecutar la consulta',
                'details' => $e->getMessage()
            ], 500);
        }
    
        return response()->json($results);
    }
    

    public function handleWithResponse(Request $request)
    {
        $prompt = $request->input('prompt');

        if (!$prompt) {
            return response()->json(['error' => 'Prompt vacío'], 400);
        }

        $sql = app(AIQueryService::class)->generateSQL($prompt);

        if (!$sql) {
            return response()->json(['error' => 'No se pudo generar SQL'], 500);
        }

        $sql = \App\Services\SQLCleaner::clean($sql);

        if (\App\Services\SQLCleaner::hasSubquery($sql)) {
            return response()->json(['error' => 'Subqueries no permitidas'], 400);
        }

        if (!app(\App\Services\SQLValidator::class)->isValid($sql)) {
            return response()->json(['error' => 'SQL inválido o no permitido'], 400);
        }

        $isAggregateQuery = preg_match('/\\b(count|sum|avg|min|max)\\s*\\(/i', $sql);

        if (!$isAggregateQuery && !preg_match('/limit\\s+\\d+/i', strtolower($sql))) {
            $sql .= ' LIMIT 100';
        }

        try {
            $results = DB::select($sql);
        } catch (\Exception $e) {
            Log::error('Error ejecutando SQL IA: ' . $e->getMessage());
            return response()->json([
                'error' => 'Error al ejecutar la consulta',
                'details' => $e->getMessage()
            ], 500);
        }

        $resultText = json_encode($results);

        $response = app(AIQueryService::class)->generateNaturalResponse($prompt, $resultText);

        return response()->json(['response' => $response]);
    }

    public function handleWithNaturalResponse(Request $request)
    {
        $prompt = $request->input('prompt');

        if (!$prompt) {
            return response()->json(['error' => 'Prompt vacío'], 400);
        }

        $sql = app(AIQueryService::class)->generateSQL($prompt);

        if (!$sql) {
            return response()->json(['error' => 'No se pudo generar SQL'], 500);
        }

        $sql = \App\Services\SQLCleaner::clean($sql);

        if (\App\Services\SQLCleaner::hasSubquery($sql)) {
            return response()->json(['error' => 'Subqueries no permitidas'], 400);
        }

        if (!app(\App\Services\SQLValidator::class)->isValid($sql)) {
            return response()->json(['error' => 'SQL inválido o no permitido'], 400);
        }

        $isAggregateQuery = preg_match('/\\b(count|sum|avg|min|max)\\s*\\(/i', $sql);

        if (!$isAggregateQuery && !preg_match('/limit\\s+\\d+/i', strtolower($sql))) {
            $sql .= ' LIMIT 100';
        }

        try {
            $results = DB::select($sql);
        } catch (\Exception $e) {
            Log::error('Error ejecutando SQL IA: ' . $e->getMessage());
            return response()->json([
                'error' => 'Error al ejecutar la consulta',
                'details' => $e->getMessage()
            ], 500);
        }

        // Convertimos resultado a JSON string para enviarle a Groq
        $resultJson = json_encode($results);

        $naturalResponse = app(AIQueryService::class)->generateNaturalResponse($prompt, $resultJson);

        if (!$naturalResponse) {
            return response()->json(['error' => 'No se pudo generar respuesta natural'], 500);
        }

        return response()->json(['response' => $naturalResponse]);
    }



    public function testRawAI(Request $request)
    {
        $prompt = $request->input('prompt');

        if (!$prompt) {
            return response()->json(['error' => 'Prompt vacío'], 400);
        }

        $response = app(AIQueryService::class)->rawChat($prompt);

        if (!$response) {
            return response()->json(['error' => 'Error al contactar con la IA'], 500);
        }

        return response()->json(['response' => $response]);
    }


}
